package com.example.vidaverdec

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.model.LatLng
// Remova a importação do FloatingActionButton se não estiver sendo usado
// import com.google.android.material.floatingactionbutton.FloatingActionButton

class Garcas : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_garcas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            // Retorna 'insets' como a última expressão nesta lambda
            insets
        }

        // --- Todos os listeners de clique dos botões devem estar aqui, fora do setOnApplyWindowInsetsListener ---

        val btnDoacoesGarcas = findViewById<Button>(R.id.btndoacoesgarcas)
        btnDoacoesGarcas.setOnClickListener {
            val doacoes = listOf(
                LatLng(-15.8958, -52.2516),  // Lar da Providência – Aragarças
            )

            val destino = doacoes.last()
            val waypointsRaw = doacoes.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val waypoints = Uri.encode(waypointsRaw) // Codifica para URL
            val uriString = "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints&travelmode=driving"
            val uri = Uri.parse(uriString)

            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        val btnHortasGarcas = findViewById<Button>(R.id.btnhortasgarcas)
        btnHortasGarcas.setOnClickListener {
            val hortas = listOf(
                LatLng(-15.872696107873198, -52.32857255900961),
                LatLng(-15.863435430605108, -52.270503907658856),
                LatLng(-15.870655606461577, -52.26732821997898),
                LatLng(-15.8936790363817,   -52.282921342688454),
                LatLng(-15.86832517699069,  -52.21053028660797),
                LatLng(-15.894919223331998, -52.32080879483646),
                LatLng(-15.86919794501143,  -52.32790471169241)
            )

            val destino = hortas.last()
            val waypoints = hortas.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val uri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
            )

            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        val btnFeirasGarcas = findViewById<Button>(R.id.btnfeirasgarcas)
        btnFeirasGarcas.setOnClickListener {
            val feiras = listOf(
                // --- ARAGARÇAS ---
                LatLng(-15.89795, -52.25180), // Feira da Lua - Rua Luís Rodrigues Magalhães
            )

            val destino = feiras.last()
            val waypoints = feiras.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val uri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
            )

            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }
    }
}
