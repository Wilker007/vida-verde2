package com.example.vidaverdec

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button // Supondo que você usa Buttons
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.model.LatLng // Supondo que você usa LatLng

class Pontal : AppCompatActivity() { // Nome da classe ajustado para Pontal
    @SuppressLint("MissingInflatedId") // Mantido, ajuste se necessário
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pontal) // Layout ajustado para activity_pontal
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets -> // Supondo ID 'main' no layout
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            // Retorna 'insets' como a última expressão nesta lambda
            insets
        }

        // --- Lógica dos botões para Pontal.kt ---
        // Adapte os IDs dos botões (ex: R.id.btndoacoespontal) e as listas de LatLng conforme necessário

        val btnDoacoesPontal = findViewById<Button>(R.id.btndoacoespontal) // Exemplo de ID
        btnDoacoesPontal.setOnClickListener {
            val doacoes = listOf(
                LatLng(-15.8440, -52.0030)   // CRAS – Pontal do Araguaia (Exemplo)
                // Adicione outros locais de doação em Pontal aqui
            )

            if (doacoes.isNotEmpty()) { // Evita erro se a lista estiver vazia
                val destino = doacoes.last()
                // Correção: Especificar o tipo do parâmetro da lambda se a lista puder estar vazia inicialmente
                val waypointsRaw = doacoes.dropLast(1).joinToString("|") { latLng: LatLng -> "${latLng.latitude},${latLng.longitude}" }
                val waypoints = Uri.encode(waypointsRaw)
                val uriString = "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints&travelmode=driving"
                val uri = Uri.parse(uriString)

                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        }

        val btnHortasPontal = findViewById<Button>(R.id.btnhortaspontal) // Exemplo de ID
        btnHortasPontal.setOnClickListener {
            val hortas = listOf<LatLng>(
                LatLng(00.0000, 00.0000)
                // Especificar o tipo da lista vazia para ajudar na inferência
                // Adicione LatLng para hortas em Pontal aqui
                // Exemplo: LatLng(-15.8400, -52.0000) // Horta Comunitária Pontal
            )
            if (hortas.isNotEmpty()) {
                val destino = hortas.last()
                // Correção: Especificar o tipo do parâmetro da lambda
                val waypoints = hortas.dropLast(1).joinToString("|") { latLng: LatLng -> "${latLng.latitude},${latLng.longitude}" }
                val uri = Uri.parse(
                    "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
                )

                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        }

        val btnFeirasPontal = findViewById<Button>(R.id.btnfeiraspontal) // Exemplo de ID
        btnFeirasPontal.setOnClickListener {
            val feiras = listOf<LatLng>(
                LatLng(-15.909652369238735, -52.25948645390799)
            // Especificar o tipo da lista vazia para ajudar na inferência
                // Adicione LatLng para feiras em Pontal aqui
                // Exemplo: LatLng(-15.8420, -52.0010) // Feira do Produtor de Pontal
            )
            if (feiras.isNotEmpty()) {
                val destino = feiras.last()
                // Correção: Especificar o tipo do parâmetro da lambda
                val waypoints = feiras.dropLast(1).joinToString("|") { latLng: LatLng -> "${latLng.latitude},${latLng.longitude}" }
                val uri = Uri.parse(
                    "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
                )

                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        }
    }
}
