package com.example.vidaverdec

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.model.LatLng
// remova 'com.google.android.material.floatingactionbutton.FloatingActionButton' se não estiver usando
// import com.google.android.material.floatingactionbutton.FloatingActionButton

class BG : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bg)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            // A lógica dos botões foi movida para fora do WindowInsetsListener
            // Deve fazer parte do fluxo normal do onCreate

            // Retorna 'insets' como a última expressão nesta lambda
            insets
        }

        // --- Todos os listeners de clique dos botões devem estar aqui, fora do setOnApplyWindowInsetsListener ---

        val btnLocation = findViewById<Button>(R.id.btnfeirasbg)
        btnLocation.setOnClickListener {
            val feiras = listOf(
                // --- BARRA DO GARÇAS ---
                LatLng(-15.88690, -52.25710), // Feira Coberta (Domingo)
                LatLng(-15.89070, -52.25290), // Bairro Santo Antônio - Rua Germano Bezerra (Quarta)
                LatLng(-15.89230, -52.25520), // Bairro Recanto das Acácias - Rua Coqueiros (Quarta)
                LatLng(-15.88910, -52.24980), // Bairro Ouro Fino - Escola Arlinda Gomes (Quinta)
                LatLng(-15.88770, -52.26140), // Av. Salomé José Rodrigues (Sexta)
                LatLng(-15.89350, -52.25400)  // Bairro Vila Maria - Associação de Bairros (Sábado)
            )

            val destino = feiras.last()
            val waypoints = feiras.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val uri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
            )
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        val btnHortas = findViewById<Button>(R.id.btnhortasbg)
        btnHortas.setOnClickListener {
            val hortas = listOf(
                LatLng(-15.872696107873198, -52.32857255900961),
                LatLng(-15.863435430605108, -52.270503907658856),
                LatLng(-15.870655606461577, -52.26732821997898),
                LatLng(-15.8936790363817,   -52.282921342688454),
                LatLng(-15.86832517699069,  -52.21053028660797),
                LatLng(-15.894919223331998, -52.32080879483646),
                LatLng(-15.86919794501143,  -52.32790471169241)
            )

            val destino = hortas.last()
            val waypoints = hortas.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val uri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
            )
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        val btnDoacoes = findViewById<Button>(R.id.btndoacoesbg)
        btnDoacoes.setOnClickListener {
            val doacoes = listOf(
                LatLng(-15.8880, -52.2610),  // Catedral Nossa Senhora da Guia – Barra do Garças
                LatLng(-15.8700, -52.2540),  // APAE – Barra do Garças
                LatLng(-15.8958, -52.2516),  // Lar da Providência – Aragarças
                LatLng(-15.8440, -52.0030)   // CRAS – Pontal do Araguaia
            )

            val destino = doacoes.last()
            val waypointsRaw = doacoes.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            val waypoints = Uri.encode(waypointsRaw)
            val uriString = "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints&travelmode=driving"
            val uri = Uri.parse(uriString)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }
    }
}
