package com.example.videverde

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "empresa.db"
        private const val DATABASE_VERSION = 1
        const val TABLE_NAME = "usuarios"
        const val COLUMN_ID = "id"
        const val COLUMN_NOME = "nome"
        const val COLUMN_SENHA = "senha"
        const val COLUMN_NOME_EMPRESA = "nome_empresa"
        const val COLUMN_ENDERECO_EMPRESA = "endereco_empresa"
        const val COLUMN_GMAIL = "gmail"
    }
    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOME + " TEXT,"
                + COLUMN_SENHA + " TEXT,"
                + COLUMN_NOME_EMPRESA + " TEXT,"
                + COLUMN_ENDERECO_EMPRESA + " TEXT,"
                + COLUMN_GMAIL + " TEXT" + ")")
        db.execSQL(createTable)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
}