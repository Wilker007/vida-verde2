package com.example.videverde


import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.videverde.ui.UserRepository

class LogFor : AppCompatActivity() {


    @SuppressLint("CutPasteId", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_for)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        lateinit var DBHelper: DBHelper
        lateinit var userRepository: UserRepository
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            DBHelper = DBHelper(this)
            userRepository = UserRepository(DBHelper)
            // Exemplo de adição de usuário
            userRepository.addUser(
                "João",
                "senha123",
                "Empresa XYZ",
                "Rua A, 123",
                "joao@gmail.com"
            )
            // Exemplo de recuperação de usuários
            val users = userRepository.getAllUsers()
            users.forEach {
                println("Nome: ${it.nome}, Empresa: ${it.nomeEmpresa}")
            }
        }
    }
}