package com.example.vidaverdec

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.gms.maps.model.LatLng

class TelaCli : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tela_cli)

        val btnLocation = findViewById<FloatingActionButton>(R.id.btnmaps)

        btnLocation.setOnClickListener {


        val feiras = listOf(
            // --- ARAGARÇAS ---
            LatLng(-15.89795, -52.25180), // Feira da Lua - Rua Luís Rodrigues Magalhães

            // --- PONTAL DO ARAGUAIA ---
            LatLng(-15.84860, -52.00550), // Feira do Produtor - Av. Airton Senna

            // --- BARRA DO GARÇAS ---
            LatLng(-15.88690, -52.25710), // Feira Coberta (Domingo)
            LatLng(-15.89070, -52.25290), // Bairro Santo Antônio - Rua Germano Bezerra (Quarta)
            LatLng(-15.89230, -52.25520), // Bairro Recanto das Acácias - Rua Coqueiros (Quarta)
            LatLng(-15.88910, -52.24980), // Bairro Ouro Fino - Escola Arlinda Gomes (Quinta)
            LatLng(-15.88770, -52.26140), // Av. Salomé José Rodrigues (Sexta)
            LatLng(-15.89350, -52.25400)  // Bairro Vila Maria - Associação de Bairros (Sábado)
        )

        // Destino final = último da lista
        val destino = feiras.last()

        // Todos os outros viram waypoints
        val waypoints = feiras.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }

        // Monta a URI do Google Maps
        val uri = Uri.parse(
            "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
        )

        // Cria a intent para abrir no Google Maps
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        startActivity(intent)
        }
    }
}