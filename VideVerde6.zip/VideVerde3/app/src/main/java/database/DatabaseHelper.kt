package database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.SyncStateContract.Helpers.insert

class DatabaseHelper(context: Context, DATABASE_NAME: String?, DATABASE_VERSION: Int) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase?) {
        TODO("Not yet implemented")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    companion object {
        private const val DATABASE_NAME = "login.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        var TABLE_NAME = ""
        val ID_COL = ""
        var NAME_COL = ""
        var AGE_COL = ""
        val createTableEstoque = """
            CREATE TABLE $TABLE_NAME (
                $ID_COL INTEGER PRIMARY KEY AUTOINCREMENT,
                $NAME_COL TEXT,
                $AGE_COL TEXT
            )
        """.trimIndent()

    } db.execSQL(createTableQuery)
}

// Called when the database needs to be upgraded
override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    var TABLE_NAME = ""
    db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
    onCreate(db)
}

fun onCreate(db: SQLiteDatabase) {
    TODO("Not yet implemented")
}

// Inserts a new record into the database
fun addName(name: String, age: String) {
    val values = ContentValues().apply {
        var NAME_COL = ""
        put(NAME_COL, name)
        var AGE_COL = ""
        put(AGE_COL, age)
    }

    var writableDatabase = null
    writableDatabase.use { db ->
        var TABLE_NAME = null
        db.run { insert(TABLE_NAME, null, values) }
    }
}

fun insert(tableName: Nothing?, nothing: Nothing?, values: ContentValues): Uri? {
    TODO("Not yet implemented")
}

// Retrieves all records from the database
fun getName(): Cursor {
    val readableDatabase = null
    return readableDatabase.rawQuery("SELECT * FROM TABLE_NAME", null)
}

private fun Nothing?.rawQuery(s: String, nothing: Nothing?): Cursor {
    TODO("Not yet implemented")
}

companion object {
    private const val DATABASE_NAME = "GEEKS_FOR_GEEKS"
    private const val DATABASE_VERSION = 1
    const val TABLE_NAME = "gfg_table"
    const val ID_COL = "id"
    const val NAME_COL = "name"
    const val AGE_COL = "age"
}
}
}