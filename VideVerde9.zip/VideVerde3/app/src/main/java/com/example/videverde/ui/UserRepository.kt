package com.example.videverde.ui

import android.annotation.SuppressLint
import android.content.ContentValues
import android.database.Cursor
import com.example.videverde.DBHelper

class UserRepository(private val dbHelper: DBHelper) {
    fun addUser (nome: String, senha: String, nomeEmpresa: String, enderecoEmpresa: String, gmail: String) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(DBHelper.COLUMN_NOME, nome)
            put(DBHelper.COLUMN_SENHA, senha)
            put(DBHelper.COLUMN_NOME_EMPRESA, nomeEmpresa)
            put(DBHelper.COLUMN_ENDERECO_EMPRESA, enderecoEmpresa)
            put(DBHelper.COLUMN_GMAIL, gmail)
        }
        db.insert(DBHelper.TABLE_NAME, null, values)
        db.close()
    }
    @SuppressLint("Range")
    fun getAllUsers(): List<User> {
        val userList = mutableListOf<User>()
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.query(DBHelper.TABLE_NAME, null, null, null, null, null, null)
        if (cursor.moveToFirst()) {
            do {
                val user = User(
                    id = cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_ID)),
                    nome = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_NOME)),
                    senha = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_SENHA)),
                    nomeEmpresa = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_NOME_EMPRESA)),
                    enderecoEmpresa = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_ENDERECO_EMPRESA)),
                    gmail = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_GMAIL))
                )
                userList.add(user)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return userList
    }
}