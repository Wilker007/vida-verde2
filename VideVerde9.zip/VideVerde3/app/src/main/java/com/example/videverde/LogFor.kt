package com.example.videverde


import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LogFor : AppCompatActivity() {


    @SuppressLint("CutPasteId", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_for)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
            val edUserName : EditText = findViewById(R.id.editTextText)
            val edPassword : EditText = findViewById(R.id.editTextTextPassword)
            val edNameh : EditText = findViewById(R.id.editTextText2)
            val edEndereco : EditText = findViewById(R.id.editTextTextPostalAddress)
            val loginButton : Button = findViewById(R.id.floatingBtnAdd)
            val newRegister = findViewById<TextView>(R.id.registration)
            val db = DBHelper(applicationContext, "healthcare", null, 1)
            loginButton.setOnClickListener {
                val username = edUserName.text.toString()
                val password = edPassword.text.toString()
                val nameh = edNameh.text.toString()
                val endereco = edEndereco.text.toString()
                if ((username.isEmpty()) || (password.isEmpty()) || (nameh.isEmpty()) || (ende.isEmpty())) {
                    Toast.makeText(this, "fill the details!", Toast.LENGTH_SHORT).show()
                }
                else {
                    if(db.login(username, password, nameh, endereco) == 1) {
                        Toast.makeText(this, "login success!", Toast.LENGTH_SHORT).show()
                        val sharedPref = getSharedPreferences("share_prefs", Context.MODE_PRIVATE)
                        val editor : SharedPreferences.Editor = sharedPref.edit()
                        editor.putString("username", username)
                        editor.apply()
                        startActivity(Intent(this, Fornecedor::class.java))
                    }
                    else {
                        Toast.makeText(this, "Invalid Username and Password", Toast.LENGTH_SHORT).show()
                    }

                }

            }

            newRegister.setOnClickListener {
                val intent = Intent(this, RegisterActivity::class.java)
                startActivity(intent)
            }

        }
    }