package database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context, DATABASE_NAME: String?, DATABASE_VERSION: Int) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase?) {
        TODO("Not yet implemented")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    companion object {
        private const val DATABASE_NAME = "veiculos.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createVeiculosTable = """
            CREATE TABLE Veiculos (
                idVeiculos INTEGER PRIMARY KEY AUTOINCREMENT,
                Cor INTEGER,
                N_Chassis INTEGER,
                Marca INTEGER,
                Modelo INTEGER
            );
        """.trimIndent()
        val createA3Table = """
            CREATE TABLE A3 (
                idA3 INTEGER PRIMARY KEY AUTOINCREMENT,
                Pequenos INTEGER,
                C_Ar_condicionado INTEGER,
                Tamanho TEXT,
                Cambio_automatico INTEGER,
                N_de_Portas INTEGER,
                Acessorios_D TEXT
            );
        """.trimIndent()
        val createC4Table = """
            CREATE TABLE C4 (
                idC4 INTEGER PRIMARY KEY AUTOINCREMENT,
                C_de_carga INTEGER,
                Dimensao TEXT
            );
        """.trimIndent()
    }
}