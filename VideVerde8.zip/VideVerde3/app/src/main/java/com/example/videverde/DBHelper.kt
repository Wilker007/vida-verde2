package com.example.videverde

import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDBHelper.db"
        private const val DATABASE_VERSION = 1
        const val TABLE_NAME = "usuarios"
        const val COLUMN_ID = "id"
        const val COLUMN_NOME = "nome"
        const val COLUMN_SENHA = "senha"
        const val COLUMN_NOME_EMPRESA = "nome_empresa"
        const val COLUMN_ENDERECO_EMPRESA = "endereco_empresa"
        const val COLUMN_GMAIL = "gmail"
    }
    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOME + " TEXT,"
                + COLUMN_SENHA + " TEXT,"
                + COLUMN_NOME_EMPRESA + " TEXT,"
                + COLUMN_ENDERECO_EMPRESA + " TEXT,"
                + COLUMN_GMAIL + " TEXT" + ")")
        db.execSQL(createTableQuery)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
    fun insertUser(name: String, senha: String): Long{
        val values = ContentValues(). apply {
            put(COLUMN_NOME, name)
            put(COLUMN_SENHA, senha)
        }
        val db = writableDatabase
        return db.insert(TABLE_NAME,null, values)
    }
    fun readUser(name: String, senha: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_NOME = ? AND $COLUMN_SENHA = ?"
        val selectionArgs = arrayOf(name, senha)
        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)
    }
}