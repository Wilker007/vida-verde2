package com.example.videverde.ui

data class User(
    val id: Int,
    val nome: String,
    val senha: String,
    val nomeEmpresa: String,
    val enderecoEmpresa: String,
    val gmail: String
)