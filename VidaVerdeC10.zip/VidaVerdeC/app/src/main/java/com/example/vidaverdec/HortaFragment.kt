package com.example.vidaverdec

import android.view.View
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.vidaverdec.databinding.FragmentHortasBinding

class HortaFragment : Fragment(R.layout.fragment_hortas) {

    private var binding: FragmentHortasBinding? = null

    private val filters = arrayOf(
        FilterItem(1, "Ordenar", closeIcon = R.drawable.ic_baseline_filter_list_24),
        FilterItem(2, "Verdura"),
        FilterItem(3, "Legumes"),
        FilterItem(4, "Frutas"),
        FilterItem(5, "Temperos"),
        FilterItem(6, "Mais Perto de você"),
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentHortasBinding.bind(view)

        binding?.let { bind ->
            filters.forEach { filter ->
                bind.chipGroupFilter.addView(filter.toChip(requireContext()))
            }
        }
    }
}


