package com.example.vidaverdec

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.vidaverdec.databinding.ActivityTelaCliBinding
import com.google.android.material.tabs.TabLayoutMediator

class TelaCli : AppCompatActivity() {

    private lateinit var binding: ActivityTelaCliBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityTelaCliBinding.inflate(layoutInflater)

        setContentView(binding.root)

        setupViews()


            }
    private fun setupViews() {
        val tabLayout = binding.addTab
        val viewPager = binding.addViewpager
        val adapter = TabViewPagerAdapter(this)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = getString(adapter.tabs[position])
        }.attach()
    }
}

class TabViewPagerAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa){

    val tabs = arrayOf(R. string.hortas, R. string.feiras, R. string.artesanatos, R. string.diversos,)
    val fragments = arrayOf(HortaFragment(), HortasFragment(), HortasFragment(), HortasFragment())

override fun getItemCount() = fragments.size



    override fun createFragment(position: Int): Fragment {
        return fragments[position]
    }
}

class HortasFragment : Fragment() {}


