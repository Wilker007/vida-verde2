package com.example.vidaverdec

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.gms.maps.model.LatLng

class TelaCli : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tela_cli)

        val btnLocation = findViewById<FloatingActionButton>(R.id.btnmaps)

        btnLocation.setOnClickListener {


        val feiras = listOf(
            // --- ARAGARÇAS ---
            LatLng(-15.89795, -52.25180), // Feira da Lua - Rua Luís Rodrigues Magalhães

            // --- PONTAL DO ARAGUAIA ---
            LatLng(-15.84860, -52.00550), // Feira do Produtor - Av. Airton Senna

            // --- BARRA DO GARÇAS ---
            LatLng(-15.88690, -52.25710), // Feira Coberta (Domingo)
            LatLng(-15.89070, -52.25290), // Bairro Santo Antônio - Rua Germano Bezerra (Quarta)
            LatLng(-15.89230, -52.25520), // Bairro Recanto das Acácias - Rua Coqueiros (Quarta)
            LatLng(-15.88910, -52.24980), // Bairro Ouro Fino - Escola Arlinda Gomes (Quinta)
            LatLng(-15.88770, -52.26140), // Av. Salomé José Rodrigues (Sexta)
            LatLng(-15.89350, -52.25400)  // Bairro Vila Maria - Associação de Bairros (Sábado)
        )

        // Destino final = último da lista
        val destino = feiras.last()

        // Todos os outros viram waypoints
        val waypoints = feiras.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }

        // Monta a URI do Google Maps
        val uri = Uri.parse(
            "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
        )

        // Cria a intent para abrir no Google Maps
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        startActivity(intent)
        }

        val btnHortas = findViewById<FloatingActionButton>(R.id.btnhorta)

        btnHortas.setOnClickListener {

            val hortas = listOf(
                LatLng(-15.872696107873198, -52.32857255900961),
                LatLng(-15.863435430605108, -52.270503907658856),
                LatLng(-15.870655606461577, -52.26732821997898),
                LatLng(-15.8936790363817,   -52.282921342688454),
                LatLng(-15.86832517699069,  -52.21053028660797),
                LatLng(-15.894919223331998, -52.32080879483646),
                LatLng(-15.86919794501143,  -52.32790471169241)
            )

            // Destino final = último da lista
            val destino = hortas.last()

            // Todos os outros viram waypoints
            val waypoints = hortas.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }

            // Monta a URI do Google Maps
            val uri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints"
            )

            // Cria a intent para abrir no Google Maps
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        val btnDoacoes = findViewById<FloatingActionButton>(R.id.btndoacoes)

        btnDoacoes.setOnClickListener {

            // Lista de locais de doação (ordem define A -> B -> C -> ...)
            val doacoes = listOf(
                LatLng(-15.8880, -52.2610),  // Catedral Nossa Senhora da Guia – Barra do Garças
                LatLng(-15.8700, -52.2540),  // APAE – Barra do Garças
                LatLng(-15.8958, -52.2516),  // Lar da Providência – Aragarças
                LatLng(-15.8440, -52.0030)   // CRAS – Pontal do Araguaia
            )

            // destino = último ponto da lista (será a letra final)
            val destino = doacoes.last()

            // waypoints = todos os anteriores (pipe-separated)
            val waypointsRaw = doacoes.dropLast(1).joinToString("|") { "${it.latitude},${it.longitude}" }
            // codifica para URL (garante que pipes e vírgulas fiquem seguros)
            val waypoints = Uri.encode(waypointsRaw)

            // monta a URI do Google Maps (sem origin: Maps usa localização atual por padrão)
            val uriString = "https://www.google.com/maps/dir/?api=1&destination=${destino.latitude},${destino.longitude}&waypoints=$waypoints&travelmode=driving"
            val uri = Uri.parse(uriString)

            // abre no app Google Maps
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }
    }
}